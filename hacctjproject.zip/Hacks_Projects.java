// Name:Sett Boss Igor "vOctave" G, Rish Fish, ARAM Prodigy Noah "Pardis Sabeti" Cha
import java.util.*;
import java.io.*;
import java.text.DecimalFormat;
import java.awt.event.*;
import javax.swing.*;
import java.awt.*;

public class Hacks_Projects
{

   public static void main(String[] args) throws IOException
   {
      System.out.println("We are hackers");
      makeRishiHappy();
      Samwich[] meal = noahDoSomething();
      Map<String, Maths> adc = pardisSabeti(meal);
      String[] lonely = autoFill(adc);
      JFrame pic = new JFrame("Overlimit");
      pic.setSize(816,488);
      pic.setLocation(100,50);
      pic.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      pic.setContentPane(new dPanel(lonely));
      pic.setVisible(true);
      
      }
   
   
   public static void makeRishiHappy() throws IOException{
      PrintWriter noah = new PrintWriter(new FileWriter ("input.txt"));
      String[] names = new String[]{"Alexandria", "Arlington", "Centreville", "Chantilly", "Clifton", "Culpeper", "Dulles", "Falls Church", "Fairfax", "Fredericksburg", "Herndon", "Leesburg", "Lorton", "Manassas Park", "Manassas", "Marshall", "McLean", "Middleburg", "Occoquan", "Purcellville", "Reston", "Spotsylvania", "Springfield", "Triangle", "Vienna", "Warrenton", "Woodbridge"};
      for(int x = 0; x<1000; x++){
      String whatever = names[(int)(Math.random()*27)];
      int actualSpeed = (int)(Math.random()*31)+40;
      int limit = (int)(Math.random()*25)+30;
      noah.println(whatever+", "+actualSpeed+", "+limit);
      }
      noah.close();
   }
   
   
   public static Samwich[] noahDoSomething() throws IOException{
   //rishi bad
      Scanner infile = new Scanner(new File("input.txt"));
      Samwich[] food = new Samwich[1000];
      //a wild noah appears
      int x = 0;
      while(infile.hasNextLine()){
         String kool = infile.nextLine();
         String[] array = kool.split(", ");
         Samwich what = new Samwich(array[0], array[1], array[2]);
         if(what.jgdif() > 0){
          food[x] = what;
          x++;
          }
         
      }
      return food;
   }
   
   public static Map<String, Maths> pardisSabeti(Samwich[] eatz) throws IOException{
      //these statistics boutta count
      Map<String, Maths> stats = new TreeMap<String, Maths>(); 
      int u = 0;
      while((eatz[u] != null)){
         Samwich blt = eatz[u];
         if(stats.containsKey(blt.getCity())){
            stats.get(blt.getCity()).add(blt.jgdif());
         } else{
            stats.put(blt.getCity(), new Maths(1, blt.jgdif()));
            }
         u++;
      }
      System.out.println(stats);
      return stats;
   }
   
   public static String[] autoFill(Map<String, Maths> stats){
      double maximus_prime = 0;
      String citius_maximus = "";
      double maximus_primes = 0;
      String citiuss_maximus = "";
      for(String s : stats.keySet()){
         if(stats.get(s).getTally() > maximus_prime){
            maximus_prime = stats.get(s).getTally();
            citius_maximus = s;
            }
         if(stats.get(s).avg() > maximus_primes){
            maximus_primes = stats.get(s).avg();
            citiuss_maximus = s;
            }
      }
     DecimalFormat df = new DecimalFormat("0.00");
     String[] thresh = new String[4];
     thresh[0] = citius_maximus;
     thresh[1] = String.valueOf(maximus_prime);
     thresh[2] = citiuss_maximus;
     thresh[3] = String.valueOf(df.format(maximus_primes));
     return thresh;
   }
}
class Samwich
{
   private String city; 
   private int speed, limit;
   
   public Samwich(String x, String y, String z)
   { 
      city = x; 
      speed = Integer.parseInt(y); 
      limit = Integer.parseInt(z); 
   }
   
   public String getCity()
   { 
      return city; 
   }
   
   public int getSpeed() 
   { 
      return speed; 
   }
   
   public int getLimit() 
   { 
      return limit; 
   }
   
   public int jgdif(){
      return speed-limit;
   }
}

class Maths 
{
   private int tally;
   private double total;
  
   public Maths(int x, int y){
      tally = x;
      total = (double)y;
   }
   public int getTally() 
   { 
      return tally; 
   }
   
   public double getTotal() 
   { 
      return total; 
   }
   public void add(int b){
      tally +=1;
      total +=b;
   }
   
   public double avg(){
      return total/tally;
   }
   public String toString(){
      DecimalFormat df = new DecimalFormat("0.00");
      return "Total incidents: " + tally +", Average speed over limit: " + df.format(avg());
   }
}

class dPanel extends JPanel  implements MouseListener 
{
   //private Timer timer;
   //rectF rishi = new rectF(
   private JButton button;
   private JButton exit;
   private JButton back;
   private JPanel second;
   private String[] nose;
   int any = 0;
   public dPanel(String[] no){
      nose = no;
      second  = new JPanel();
      second.setLayout(new GridLayout(2,1));
      add(second);
      setFocusable(true);
      requestFocusInWindow();
      addMouseListener(this);
      setLayout(new FlowLayout());
      button = new JButton("Run program (Randomly generated data)");
      button.addActionListener(new rishiButListens());
      button.setFont(new Font("Comic Sans MS", Font.BOLD, 25));
      exit = new JButton("Click to exit");
      exit.addActionListener(new noahLeftUs());
      exit.setFont(new Font("Comic Sans MS", Font.BOLD, 15));
      back = new JButton("Go back");
      back.addActionListener(new noahCameBack());
      back.setFont(new Font("Comic Sans MS", Font.BOLD, 15));
      second.add(button);
      second.add(exit);
   }
   @Override public void mouseReleased(MouseEvent e) {}
   @Override public void mouseClicked(MouseEvent e) {}
   @Override public void mouseEntered(MouseEvent e) {}
   @Override public void mouseExited(MouseEvent e) {}
   @Override public void mousePressed(MouseEvent e) {}
     
 

   
   public void paintComponent(Graphics g){
      super.paintComponent(g);
      Graphics2D g2d = (Graphics2D) g;
      if(any==0){
         ImageIcon clickbait = new ImageIcon(getClass().getResource("OVERLIMIT.png"));
         g.drawImage(clickbait.getImage(), 0, 0, 816, 488, null);
      } else{
      ImageIcon pic = new ImageIcon(getClass().getResource("NOVA.png"));
      g.drawImage(pic.getImage(), 245, 100, 400, 240, null);
      setBackground(new Color(255,170,255));
      g.drawString("City with most speeding incidents: "+nose[0],50,150);
      g.drawString("At "+nose[1]+" incidents.",75,170);
      g.drawString("City with highest average speed OVERLIMIT: "+nose[2], 50, 210);
      g.drawString("At "+nose[3]+" mph.", 75, 230);
    }  
   }
   private class rishiButListens implements ActionListener
   {
      public void actionPerformed(ActionEvent e){
         any = 1;
         second.remove(button);
         //second.add(back);
         repaint();
         
      }
   }
   private class noahLeftUs implements ActionListener
   {
      public void actionPerformed(ActionEvent e){
         System.exit(0);
      }
   }
   private class noahCameBack implements ActionListener
   {
      public void actionPerformed(ActionEvent e){
         any = 0;
         //second.remove(back);
         second.remove(exit);
         second.add(button);
         second.add(exit);
         repaint();
      }
   }
}



class rectF
{
   public double left, right, top, bottom;
   
   public rectF(double left, double top, double right, double bottom) {
                      
      this.left = left;
      this.right = right;
      this.top = top;
      this.bottom = bottom;
   }
   
   public boolean contains(double x, double y) {
      return x >= left && x < right && y >= top && y < bottom;  
   }
}
